﻿int[,] pixel = new int[1024, 840];

pixel[0, 0] = 1;
pixel[0, 1] = 2;
pixel[0, 2] = 56;
//.....

pixel[0, 840] = 56;
/*
 
A rectangular array is a multi-dimensional array where 
all rows have the same number of columns.
It is defined with a fixed size for each dimension.

*/

