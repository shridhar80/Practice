﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//What do you mean by Clonning
//Mother of all classes in C#  is Object (object) class

namespace ClonningApp
{
    public interface ICloneable
    {
        object Clone();

    }
}
