﻿namespace GraphicsLib
{
    public class Shape
    {

        public Shape() {
            Console.WriteLine("Shape constructor is called.");
        }  

        public   void Draw()
        {
            Console.WriteLine("Drawing generice Shape");

        }

    }
}
