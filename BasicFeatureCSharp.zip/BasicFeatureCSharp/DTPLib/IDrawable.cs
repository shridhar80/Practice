﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTPLib
{

    //Every interface is by default abstract

    public  interface IDrawable
    {  //all methods of interface should be abstract methods
        void Draw();
    }
}
