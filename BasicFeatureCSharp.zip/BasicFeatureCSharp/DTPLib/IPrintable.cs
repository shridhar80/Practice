﻿namespace DTPLib
{
    public interface  IPrintable
    {
        //all methods of interface should be abstract
      void Print();
    }
}
